package com.sysadmin.mapreduce.filter;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.RecordWriter;
import org.apache.hadoop.mapreduce.TaskAttemptContext;

public class FilterRecordWriter extends RecordWriter<Text, NullWritable> {

	private FSDataOutputStream atguiguout = null;
	private FSDataOutputStream otherout = null;

	public FilterRecordWriter(TaskAttemptContext job) {
		Configuration configuration = job.getConfiguration();

		try {
			// ��ȡ�ļ�ϵͳ
			FileSystem fs = FileSystem.get(configuration);

			// ���������ļ��������
			atguiguout = fs.create(new Path("h:/hadoop/output/atguigu.txt"));
			otherout = fs.create(new Path("h:/hadoop/output/other.txt"));

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void write(Text key, NullWritable value) throws IOException, InterruptedException {

		// ���������key�Ƿ����atguigu
		if (key.toString().contains("atguigu")) {
			atguiguout.write(key.toString().getBytes());
		} else {
			otherout.write(key.toString().getBytes());
		}
	}

	@Override
	public void close(TaskAttemptContext context) throws IOException, InterruptedException {

		if (atguiguout != null) {
			atguiguout.close();
		}
		if (otherout != null) {
			otherout.close();
		}
	}

}
