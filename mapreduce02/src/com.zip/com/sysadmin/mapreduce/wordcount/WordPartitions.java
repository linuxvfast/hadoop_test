package com.sysadmin.mapreduce.wordcount;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;

public class WordPartitions extends Partitioner<Text, IntWritable> {

	@Override
	public int getPartition(Text key, IntWritable value, int numPartitions) {
		// ��ȡ����key������ĸ
		String substring = key.toString().substring(0, 1);

		// ת����ĸΪASCII
		char[] charArray = substring.toCharArray();
		int result = charArray[0];

		// ������ż����
		if (result % 2 == 0) {
			return 0;
		} else {
			return 1;
		}
	}

}
