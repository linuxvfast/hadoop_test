package com.sysadmin.mapreduce.distributedcache;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class DistributedMapper extends Mapper<LongWritable, Text, Text, NullWritable> {

	// ���pd.txt������
	private Map<String, String> pdMap = new HashMap<>();

	@Override
	protected void setup(Context context) throws IOException, InterruptedException {

		// ��ȡ���ݣ�����ŵ�����
		BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream("pd.txt")));

		String line;
		while (StringUtils.isNotEmpty(line = reader.readLine())) {// ��ȡһ�����ݲ�Ϊ��

			// �и�
			String[] fields = line.split("\t");

			// �������ݵ�����
			pdMap.put(fields[0], fields[1]);
		}

		// �ر�reader
		reader.close();
	}

	Text k = new Text();

	@Override
	protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {

		// ����:�ϲ�pd.txt��order.txt
		String line = value.toString();

		String[] fields = line.split("\t");

		// ��ȡ����id
		String orderId = fields[1];

		// ��ȡ��Ʒ����
		String pdname = pdMap.get(orderId);

		// ƴ��
		k.set(line + "\t" + pdname);

		// д��
		context.write(k, NullWritable.get());
	}
}
