package com.sysadmin.mapreduce.ordertop;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class OrderMapper extends Mapper<LongWritable, Text, OrderBean, NullWritable> {

	OrderBean bean = new OrderBean();

	@Override
	protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
		// ��ȡ����
		String line = value.toString();

		// ��ȡ�ֶ�
		String[] fields = line.split("\t");
		System.out.println(fields);

		// ��װbean
		bean.setOrderId(fields[0]);
		bean.setPrice(Double.parseDouble(fields[2]));

		// д��
		context.write(bean, NullWritable.get());

	}
}
