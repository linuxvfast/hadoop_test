package com.sysadmin.mapreduce.ordertop;

import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;

public class OrderGroupingComparator extends WritableComparator{

	//�ղι���
	public OrderGroupingComparator () {
		super(OrderBean.class,true);
	}
	
	//��д�ȽϷ���
	@SuppressWarnings("rawtypes")
	@Override
	public int compare(WritableComparable a, WritableComparable b) {
		OrderBean aBean = (OrderBean) a;
		OrderBean bBean = (OrderBean) b;
		return aBean.getOrderId().compareTo(bBean.getOrderId());
	}
}
