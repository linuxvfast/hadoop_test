package com.sysadmin.mapreduce.flowsort;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

//��ȡ��������:13480253104	180	180	360
public class FlowSortMapper extends Mapper<LongWritable, Text, FlowBean, Text> {

	FlowBean bean = new FlowBean();
	Text v = new Text();

	@Override
	protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
		// ��ȡһ������
		String line = value.toString();

		// ��ȡ�ֶ�
		String[] field = line.split("\t");

		// ��װbean�����Լ���ȡ�绰��
		long upFlow = Long.parseLong(field[1]);
		long downFlow = Long.parseLong(field[2]);

		bean.set(upFlow, downFlow);
		v.set(field[0]);

		// д����
		context.write(bean, v);
	}
}
