package com.sysadmin.mapreduce.flow;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class FlowMapper extends Mapper<LongWritable, Text, Text, FlowBean> {

	FlowBean bean = new FlowBean();
	Text k = new Text();

	@Override
	protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {

		// ��ȡһ������
		String line = value.toString();

		// ��ȡ�ֶ�
		String[] fields = line.split("\t");

		// ��װbean�����Լ���ȡ�绰��
		String phoneNum = fields[1];
		long upFlow = Long.parseLong(fields[fields.length - 3]);
		long downFlow = Long.parseLong(fields[fields.length - 2]);

//		FlowBean bean = new FlowBean(upFlow,downFlow);
		bean.set(upFlow, downFlow);
		k.set(phoneNum);
		// д��ȥ
//		context.write(new Text(phoneNum), bean);
		context.write(k, bean); // �Ż�֮���д��

	}
}
