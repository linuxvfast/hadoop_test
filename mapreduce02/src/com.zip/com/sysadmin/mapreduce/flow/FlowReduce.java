package com.sysadmin.mapreduce.flow;

import java.io.IOException;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class FlowReduce extends Reducer<Text, FlowBean, Text, FlowBean> {

	@Override
	protected void reduce(Text key, Iterable<FlowBean> values, Context context)
			throws IOException, InterruptedException {
		// ����������
		long sum_upflow = 0;
		long sum_downflow = 0;

		for (FlowBean bean : values) {
			sum_upflow += bean.getUpFlow();
			sum_downflow += bean.getDownFlow();
		}
		
		//�������
		context.write(key, new FlowBean(sum_upflow, sum_downflow));
	}
}
